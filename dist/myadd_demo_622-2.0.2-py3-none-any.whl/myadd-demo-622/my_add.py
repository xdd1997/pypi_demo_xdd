def my_add(a,b):
    return a+b
