# -*- coding: utf-8 -*-
# @File   : test.py
# @Author : xdd2026@qq.com
# @Data   : 2022/11/16 19:53 
# @Purpose:

from my_add import my_add

c = my_add(1,2)
print(c)