## install

```
pip install myadd-demo-622
```

## use

```
import pypi_demo_xdd
```



## url

[https://pypi.org/project/myadd-demo-622/](https://pypi.org/project/myadd-demo-622/)

https://github.com/xdd1997/pypi_demo_xdd



