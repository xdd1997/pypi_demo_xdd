## install

```
pip install myadd-demo-622
```

## use

```
import pypi_demo_xdd
```

